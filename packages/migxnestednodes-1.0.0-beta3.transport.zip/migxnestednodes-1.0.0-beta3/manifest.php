<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxnestednodes-1.0.0-beta3/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2186452ffe9df772292f393fea8be66f',
      'native_key' => 'migxnestednodes',
      'filename' => 'modNamespace/b36fa8e3f481a658c356bf3fb6938091.vehicle',
      'namespace' => 'migxnestednodes',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '141c50ad65bf386657aaf858c7375ae1',
      'native_key' => 1,
      'filename' => 'modCategory/9893d853831d131be8e2768d4c28bed5.vehicle',
      'namespace' => 'migxnestednodes',
    ),
  ),
);