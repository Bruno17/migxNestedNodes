<?php
require_once (dirname(dirname(__FILE__)) . '/mnnresourcenodeselection.class.php');
class mnnResourceNodeSelection_mysql extends mnnResourceNodeSelection {}