<?php
require_once (dirname(dirname(__FILE__)) . '/mnnnode.class.php');
class mnnNode_mysql extends mnnNode {}