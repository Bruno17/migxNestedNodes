<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'mnnNode',
    1 => 'mnnChildNode',
    2 => 'mnnResourceNodeSelection',
    3 => 'mnnNodeNodeSelection',
  ),
);