<?php
require_once (dirname(dirname(__FILE__)) . '/mnnnodenodeselection.class.php');
class mnnNodeNodeSelection_mysql extends mnnNodeNodeSelection {}