<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxnestednodes-1.0.0-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5b432002d4ab575f83808a22c3af2b93',
      'native_key' => 'migxnestednodes',
      'filename' => 'modNamespace/babb5822a895d20ce9a012aa1e519e83.vehicle',
      'namespace' => 'migxnestednodes',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '77c84a9569e6ae0aa0e411a6f9e4b61e',
      'native_key' => 1,
      'filename' => 'modCategory/9caa33c2ec5aaa57c14ea71b616ab288.vehicle',
      'namespace' => 'migxnestednodes',
    ),
  ),
);