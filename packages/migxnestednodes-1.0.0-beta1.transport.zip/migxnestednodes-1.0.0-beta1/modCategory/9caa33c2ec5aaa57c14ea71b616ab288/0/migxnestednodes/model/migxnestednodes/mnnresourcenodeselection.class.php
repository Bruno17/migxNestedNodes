<?php
class mnnResourceNodeSelection extends xPDOSimpleObject {}