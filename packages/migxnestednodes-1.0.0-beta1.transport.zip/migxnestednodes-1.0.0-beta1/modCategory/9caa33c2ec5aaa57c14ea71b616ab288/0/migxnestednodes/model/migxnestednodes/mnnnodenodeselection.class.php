<?php
class mnnNodeNodeSelection extends xPDOSimpleObject {}