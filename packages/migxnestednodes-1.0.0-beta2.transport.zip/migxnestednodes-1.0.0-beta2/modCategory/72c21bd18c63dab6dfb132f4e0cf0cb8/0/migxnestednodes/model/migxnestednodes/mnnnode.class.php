<?php
class mnnNode extends xPDOSimpleObject {}