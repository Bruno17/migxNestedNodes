<?php
require_once (dirname(dirname(__FILE__)) . '/mnnchildnode.class.php');
class mnnChildNode_mysql extends mnnChildNode {}