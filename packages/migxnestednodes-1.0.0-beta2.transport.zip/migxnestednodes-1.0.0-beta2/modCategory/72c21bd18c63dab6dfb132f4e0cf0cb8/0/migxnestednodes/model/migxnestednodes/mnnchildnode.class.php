<?php
class mnnChildNode extends xPDOSimpleObject {}