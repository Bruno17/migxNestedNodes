<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxnestednodes-1.0.0-beta2/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '6e051a0ee17f4a91d01c9614330efcc8',
      'native_key' => 'migxnestednodes',
      'filename' => 'modNamespace/94b2466d8b537110f81b237338478f89.vehicle',
      'namespace' => 'migxnestednodes',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3d3f78697aedba73831c3b9e0fd01c45',
      'native_key' => 1,
      'filename' => 'modCategory/72c21bd18c63dab6dfb132f4e0cf0cb8.vehicle',
      'namespace' => 'migxnestednodes',
    ),
  ),
);